def test_sanity():
    from nosexcover import XCoverage
