# pylint:disable=W0404
"""check warning on local disabling
"""
__revision__ = 1

