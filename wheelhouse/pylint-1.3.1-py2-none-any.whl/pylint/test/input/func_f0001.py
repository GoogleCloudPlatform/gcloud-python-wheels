"""test astroid error
"""
import whatever
__revision__ = None
