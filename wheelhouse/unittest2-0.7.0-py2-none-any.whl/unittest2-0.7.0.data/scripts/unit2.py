#!python

__unittest = True

from unittest2.main import main

main(module=None)
