"""Common imports for generated fusiontables client library."""
# pylint:disable=wildcard-import

from apitools.base.py.testing.testclient.fusiontables_v1_client import *
from apitools.base.py.testing.testclient.fusiontables_v1_messages import *
