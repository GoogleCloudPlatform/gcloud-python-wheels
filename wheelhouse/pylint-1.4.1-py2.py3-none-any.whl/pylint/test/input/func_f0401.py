"""test failed import
"""

__revision__ = 0

def function():
    """yo"""
    from tutu import toto
    print(toto)
