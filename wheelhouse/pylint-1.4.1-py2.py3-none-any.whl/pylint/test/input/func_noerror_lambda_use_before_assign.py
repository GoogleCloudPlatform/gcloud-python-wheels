"""https://www.logilab.net/elo/ticket/18862"""

__revision__ = 1
def function():
    """hop"""
    ggg = lambda: xxx
    xxx = 1
    print(ggg())
