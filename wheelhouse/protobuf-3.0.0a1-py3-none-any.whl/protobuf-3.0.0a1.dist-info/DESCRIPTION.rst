Protocol Buffers are Google's data interchange format.


