"""test name defined in generator expression are not available
outside the genexpr scope
"""

print(n)  # [undefined-variable]
