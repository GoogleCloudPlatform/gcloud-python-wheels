"""This file does not have a final newline."""

# +1:[missing-final-newline]
print(1)