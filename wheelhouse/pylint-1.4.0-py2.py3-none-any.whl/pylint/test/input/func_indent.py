# pylint: disable=print-statement
"""docstring"""
__revision__ = '$Id: func_indent.py,v 1.4 2003-10-17 21:59:31 syt Exp $'

def totoo():
 """docstring"""
 print('malindented')

def tutuu():
    """docstring"""
    print('good indentation')

def titii():
     """also malindented"""
     1  # and this.

def tataa(kdict):
    """blank line unindented"""
    for key in ['1', '2', '3']:
        key = key.lower()

        if key in kdict:
            del kdict[key]

